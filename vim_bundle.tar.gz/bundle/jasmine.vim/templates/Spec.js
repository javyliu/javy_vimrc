describe('', function () {
  beforeEach(function () {
    
  });

  it('should...', function () {
    expect(condition).toEqual();
  });
});
