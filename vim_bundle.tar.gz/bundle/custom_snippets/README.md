custom_snippets
===============

some special snippets in development rails
